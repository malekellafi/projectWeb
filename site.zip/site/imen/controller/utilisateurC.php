<?php
include('config.php');

class UtilisateurC{
    public function listUtilisateur()
    {
        $db=config::getConnexion();
        $sql= 'SELECT * FROM utilisateur';
      
       try{
        $list =$db->query($sql);
        return $list;
       } catch(Exception $e)
       {
        die("Ereur:" .$e->getMessage());
       }
    } 

    /*public function verif($nom,$prenom,$email)
    {
        $db=config::getConnexion();
        $sql= "SELECT * FROM utilisateur where nom=':nom' and prenom=':prenom' and email=':email' ";
      
       try{
        $res =$db->query($sql);
        return $res;
       } catch(Exception $e)
       {
        die("Ereur:" .$e->getMessage());
       }
    } */

    public function verif($nom, $prenom, $email)
{
    $db = config::getConnexion();
    $sql = "SELECT * FROM utilisateur WHERE nom = :nom AND prenom = :prenom AND email = :email";

    try {
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    } catch (Exception $e) {
        die("Erreur: " . $e->getMessage());
    }
}


    function deleteUtilisateur($id)
    {
        $sql="DELETE FROM utilisateur WHERE id= :id";
        $db=config :: getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(":id",$id);
        try
        {
            $req->execute();

        }catch(Exception $e) { die("Error:". $e->getMessage());}
    }
    
    public function addUtilisateur($nom, $prenom, $email, $mdp,$rol)
  {
    $db = config::getConnexion();
    $sql = 'INSERT INTO utilisateur (nom, prenom, email, mdp,rol) VALUES(:nom, :prenom, :email, :mdp,:rol)';
    
    try
    {
      
        
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
        $stmt->bindParam(':prenom', $prenom, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':mdp', $mdp, PDO::PARAM_STR);
        $stmt->bindParam(':rol', $rol, PDO::PARAM_INT);
        $stmt->execute();
    }
    catch (PDOException $e)
    {
        die("Erreur lors de l'insertion dans la base de données: " . $e->getMessage());
    }
  }

    
    function updateUtilisateur($id,$nom,$prenom,$email,$mdp,$bloquer) {
        $db=config::getConnexion();
        $sql = 'UPDATE  utilisateur SET  nom=:nom, prenom=:prenom,email=:email,mdp=:mdp,bloquer=:bloquer WHERE id=:id';
                
         $stmt = $db->prepare($sql);
         $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':mdp', $mdp);
        $stmt->bindParam(':bloquer', $bloquer);
        $stmt->execute(['nom'=>$nom,'prenom'=>$prenom,'email'=>$email,'mdp'=>$mdp,'bloquer'=>$bloquer,'id'=>$id]);
        
     }
    
     function selectUtilisateur($email) {
        $db=config::getConnexion();
        $sql = "SELECT * FROM `utilisateur` WHERE `email` = :email and bloquer=0";
                
         $stmt = $db->prepare($sql);
       
        $stmt->bindParam(':email', $email);
                $stmt->execute();
        return $stmt;
     }
     
     function BloquerUtilisateur($email) {
        $db=config::getConnexion();
        $sql = "UPDATE  `utilisateur` SET  bloquer=1 WHERE `email` = :email";   
         $stmt = $db->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
     }
}

 
?>
