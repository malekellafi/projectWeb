
<?php  
include("../../../controller/utilisateurC.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id=$_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];
    $bloquer = $_POST['bloquer'];
   $Utilisateur=new UtilisateurC();
   $Utilisateur->updateUtilisateur($id,$nom,$prenom,$email,$mdp,$bloquer);

    header("Location:tables.php");
    exit();
}
  
?>