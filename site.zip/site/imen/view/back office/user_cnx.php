

<?php
session_start();
include('../../controller/utilisateurC.php');
//include("../../config.php");

if (isset($_POST['email']) && isset($_POST['mdp'])) {
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];

    //$db = config::getConnexion();
    $utilisateur= new UtilisateurC();
    $tab=$utilisateur->selectUtilisateur($email);
    /// en recuper le role de utilisateur
    foreach($tab as $utilisateur){
   $r=$utilisateur["rol"];
   $pass=$utilisateur["mdp"];
   $user=$utilisateur["email"];
    }
    //////////
    if ($tab->rowCount()>0 and $user==$_POST['email'] and $pass==$_POST['mdp'])
    {
        switch ($r)
        {
            case 1:
                header("Location:../back office/admin/tables.php");
                break;
            case 2:
              header("Location:../../../omayma/backoffice/tables.php?page=produit.php");
                break;
                case 3:
                    header("Location:../../../hiba/view/back office/afficherBackExec.php");
                    break;
                    case 4:
                       header("Location:../../../malek/Views/back/index.html");
                        break;
                        case 5:
                            header("Location:../front office/contact.html");
                            break;
                            default:
        }

}elseif ($tab->rowCount()>0 and $user==$_POST['email'] and $pass!=$_POST['mdp'])
    {
       $x=$_SESSION["echec"];
       $x=$x+1;
       $_SESSION["echec"]=$x;
       if($_SESSION["echec"]<=3){
        header("Location:../front office/sign-in.php?mess=3");
       }else{
        $util= new UtilisateurC();
        $req=$util->BloquerUtilisateur($email);
        header("Location:../front office/sign-in.php?mess=2");
       }
      //   
      }      
      else {
               header("Location:../front office/sign-in.php?mess=1");
      }
   

}
?>
