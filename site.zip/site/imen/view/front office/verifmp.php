<?php
    require '../../controller/utilisateurC.php';

    $nom= $_POST['nom'];
    $prenom= $_POST['prenom'];
    $email= $_POST['email'];
   
    $c=new UtilisateurC();
    $tab=$c->verif($nom,$prenom,$email);
    
    foreach($tab as $utilisateur)
{
    
    if($utilisateur["email"]==$email)
    {
        
        $dest = $utilisateur["email"];

  $sujet = " Mot de Passe";
  $corp = "Bonjour ". $utilisateur['prenom']. "\n Vous avez oubliee votre mot de passe? \n votre mot de passe est:". $utilisateur['mdp']." . \n administrateur site Tourathna.tn  \n Cordialement ";
  
  $headers = "From:imen.oun@esprit.tn";
  if($utilisateur["email"]==$email)
            if (mail($dest, $sujet, $corp, $headers)) {
                    echo "Email envoyé avec succès à $dest ...";
                    header("location:sign-in.php?mess=4");
                } else {
                    echo "Échec de l'envoi de l'email...";
                }
        //
    }
    else {
        
        echo " votre adresse inexistant ";
    }
}

    
?>
