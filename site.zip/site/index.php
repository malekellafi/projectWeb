<?php

header("location:imen/view/front office/index.php");

?>